import "dotenv/config";
import express from "express";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { Q, seedIfEmpty } from "./lib/db.js";
import { runLLM } from "./lib/llm.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: "256kb" }));

// 기본 보안 헤더
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  next();
});
// 경량 요청 로깅
app.use((req, res, next) => { const t = Date.now(); res.on("finish", () => console.log(`${new Date().toISOString()} ${req.method} ${req.path} ${res.statusCode} ${Date.now() - t}ms`)); next(); });

app.use(express.static(path.join(__dirname, "public")));

// 인메모리 레이트리밋 (IP+키 기준)
const rl = new Map();
function rateLimit(max, windowMs) {
  return (req, res, next) => {
    const id = (req.ip || "") + "|" + (req.body?.publicKey || req.headers["x-public-key"] || "");
    const t = Date.now(); const e = rl.get(id) || { c: 0, t };
    if (t - e.t > windowMs) { e.c = 0; e.t = t; }
    e.c++; rl.set(id, e);
    if (e.c > max) return res.status(429).json({ error: "요청이 너무 많습니다. 잠시 후 다시 시도해 주세요." });
    next();
  };
}

const PLANS = {
  free:    { label: "Free",    price: 0,      conv: 100,   channels: 1,   seats: 1 },
  starter: { label: "Starter", price: 49000,  conv: 1000,  channels: 1,   seats: 1 },
  growth:  { label: "Growth",  price: 149000, conv: 5000,  channels: 3,   seats: 5 },
  scale:   { label: "Scale",   price: 399000, conv: 20000, channels: 999, seats: 999 },
};

const seed = seedIfEmpty();
console.log("\n=== GOWON Talk 서버 준비 완료 ===");
console.log("Workspace public key (위젯용):", seed.publicKey);
console.log("Agent token (콘솔 로그인용):", seed.token);
if (seed.password) console.log("관리자 로그인:", seed.email, "/ 비밀번호:", seed.password);
console.log("랜딩: http://localhost:" + (process.env.PORT || 3000) + "/   콘솔: /console");
console.log("================================\n");

// 핵심: AI 응대 1턴 처리 (위젯·카카오 공통)
async function handleTurn(ws, conversationId, channel, customerName, text) {
  let cid = conversationId;
  const isNew = !cid || !Q.getConversation(cid);
  if (isNew) {
    const limit = (PLANS[Q.getPlan(ws.id)] || PLANS.free).conv;
    if (Q.monthlyConvCount(ws.id) >= limit)
      return { conversationId: null, status: "limit", reply: "이번 달 상담 한도에 도달했습니다. 요금제를 업그레이드하면 계속 응대할 수 있어요." };
    cid = Q.createConversation(ws.id, channel, customerName);
  }
  Q.addMessage(cid, "user", text);

  const conv = Q.getConversation(cid);
  if (conv.status === "agent") {
    return { conversationId: cid, status: "agent", reply: null }; // 상담사가 인계받은 대화는 AI 미개입
  }

  const history = Q.messages(cid).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.content }));
  const kb = Q.kbByWorkspace(ws.id);
  const out = await runLLM({ provider: ws.llm_provider, model: ws.llm_model }, kb, history);

  Q.addMessage(cid, "ai", out.reply, out.intent);
  const status = out.needs_human ? "needs_human" : "ai_handling";
  Q.setStatus(cid, status, out.csat);
  return { conversationId: cid, status, reply: out.reply, intent: out.intent };
}

// 인증 미들웨어
function publicAuth(req, res, next) {
  const ws = Q.workspaceByKey(req.body.publicKey || req.query.publicKey || req.headers["x-public-key"]);
  if (!ws) return res.status(401).json({ error: "유효하지 않은 public key" });
  req.ws = ws; next();
}
function agentAuth(req, res, next) {
  const t = (req.headers.authorization || "").replace("Bearer ", "");
  const ag = Q.agentByToken(t);
  if (!ag) return res.status(401).json({ error: "인증 실패" });
  req.agent = ag; next();
}

// ---- 공개 위젯 API ----
app.post("/api/chat", rateLimit(30, 60000), publicAuth, async (req, res) => {
  const { conversationId, channel = "web", customerName } = req.body;
  let { message } = req.body;
  if (!message || typeof message !== "string") return res.status(400).json({ error: "message 필요" });
  message = message.slice(0, 2000); // 입력 길이 제한 (프롬프트 인젝션·남용 완화)
  const r = await handleTurn(req.ws, conversationId, channel, customerName, message);
  res.json(r);
});

app.get("/api/conversation/:id", publicAuth, (req, res) => {
  res.json({ messages: Q.messages(req.params.id), conversation: Q.getConversation(req.params.id) });
});

// ---- 카카오 채널 웹훅 (스켈레톤) ----
// 실연동 시 카카오 비즈니스 채널 콘솔에서 이 URL을 등록하고, 서명 검증을 추가하세요.
app.post("/webhook/kakao", express.json(), async (req, res) => {
  // 서명 검증: KAKAO_WEBHOOK_SECRET 설정 시 x-gowon-signature(HMAC-SHA256) 필수
  const secret = process.env.KAKAO_WEBHOOK_SECRET;
  if (secret) {
    const sig = req.headers["x-gowon-signature"] || "";
    const expected = crypto.createHmac("sha256", secret).update(JSON.stringify(req.body)).digest("hex");
    if (sig.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected)))
      return res.status(401).json({ error: "서명 검증 실패" });
  }
  const ws = Q.workspaceByKey(process.env.KAKAO_WORKSPACE_KEY || seed.publicKey);
  const userText = req.body?.userRequest?.utterance || req.body?.message || "";
  const userId = req.body?.userRequest?.user?.id || "kakao-user";
  if (!userText) return res.json({ version: "2.0", template: { outputs: [{ simpleText: { text: "메시지를 입력해 주세요." } }] } });

  const r = await handleTurn(ws, null, "kakao", `카카오:${userId.slice(0, 6)}`, userText);
  const text = r.reply || "상담사가 곧 답변드리겠습니다.";
  // 카카오 오픈빌더 응답 포맷
  res.json({ version: "2.0", template: { outputs: [{ simpleText: { text } }] } });
});

// ---- 상담사 콘솔 API ----
app.get("/api/console/conversations", agentAuth, (req, res) => {
  res.json(Q.listConversations(req.agent.workspace_id));
});
app.get("/api/console/conversations/:id", agentAuth, (req, res) => {
  res.json({ conversation: Q.getConversation(req.params.id), messages: Q.messages(req.params.id) });
});
app.post("/api/console/conversations/:id/takeover", agentAuth, (req, res) => {
  Q.setStatus(req.params.id, "agent");
  Q.addAudit(req.agent.workspace_id, req.agent.email, "takeover", req.params.id, req.ip);
  res.json({ ok: true });
});
app.post("/api/console/conversations/:id/reply", agentAuth, (req, res) => {
  Q.addMessage(req.params.id, "agent", req.body.message);
  Q.setStatus(req.params.id, "agent");
  res.json({ ok: true });
});
app.post("/api/console/conversations/:id/resolve", agentAuth, (req, res) => {
  Q.setStatus(req.params.id, "resolved", req.body.csat);
  res.json({ ok: true });
});
// 상담사 코파일럿: AI 답변 초안 제안
app.post("/api/console/conversations/:id/suggest", agentAuth, async (req, res) => {
  const conv = Q.getConversation(req.params.id);
  if (!conv) return res.status(404).json({ error: "대화를 찾을 수 없습니다." });
  const ws = Q.workspaceById(req.agent.workspace_id);
  const history = Q.messages(req.params.id).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.content }));
  const kb = Q.kbByWorkspace(req.agent.workspace_id);
  const out = await runLLM({ provider: ws.llm_provider, model: ws.llm_model }, kb, history);
  res.json({ draft: out.reply, intent: out.intent });
});
// 팀(상담사) 목록
app.get("/api/console/team", agentAuth, (req, res) => res.json(Q.listAgents(req.agent.workspace_id)));

// ---- 지식베이스 관리 ----
app.get("/api/console/kb", agentAuth, (req, res) => res.json(Q.kbByWorkspace(req.agent.workspace_id)));
app.post("/api/console/kb", agentAuth, (req, res) => {
  const { question, answer, keywords, category } = req.body;
  const id = Q.addKb(req.agent.workspace_id, question, answer, keywords || "", category || "공용");
  res.json({ id });
});
app.delete("/api/console/kb/:id", agentAuth, (req, res) => { Q.delKb(req.agent.workspace_id, req.params.id); res.json({ ok: true }); });

// ---- 대시보드 ----
app.get("/api/console/stats", agentAuth, (req, res) => res.json(Q.stats(req.agent.workspace_id)));

// ---- 임베드 위젯 스크립트 ----
app.get("/widget.js", (req, res) => {
  res.type("application/javascript").sendFile(path.join(__dirname, "public", "widget.js"));
});

// ---- 봇 빌더 설정 ----
app.get("/api/console/settings", agentAuth, (req, res) => {
  const s = Q.getSettings(req.agent.workspace_id) || {};
  res.json({ bot_name: s.bot_name || "GOWON Talk", accent: s.accent || "#5B53E8", welcome: s.welcome || "안녕하세요! 무엇을 도와드릴까요?", channels: s.channels ? JSON.parse(s.channels) : { web: true, kakao: false, instagram: false } });
});
app.post("/api/console/settings", agentAuth, (req, res) => { Q.saveSettings(req.agent.workspace_id, req.body); res.json({ ok: true }); });

// ---- 요금제 · 사용량 ----
app.get("/api/console/plan", agentAuth, (req, res) => {
  const plan = Q.getPlan(req.agent.workspace_id);
  const limits = PLANS[plan] || PLANS.free;
  res.json({ plan, limits, usage: Q.monthlyConvCount(req.agent.workspace_id), plans: PLANS, tossClientKey: process.env.TOSS_CLIENT_KEY || "" });
});

// ---- 토스페이먼츠 결제 승인 ----
app.post("/api/billing/confirm", agentAuth, async (req, res) => {
  const { paymentKey, orderId, amount, plan } = req.body;
  const secret = process.env.TOSS_SECRET_KEY;
  if (!secret) { // 키 미설정 시 데모 승인 (실서비스에서는 반드시 키 설정)
    Q.setPlan(req.agent.workspace_id, plan);
    Q.addSubscription(req.agent.workspace_id, { plan, status: "demo", amount, payment_key: paymentKey || "demo", order_id: orderId || "demo" });
    Q.addAudit(req.agent.workspace_id, req.agent.email, "plan_change", plan + " (demo)", req.ip);
    return res.json({ ok: true, demo: true, plan });
  }
  try {
    const r = await fetch("https://api.tosspayments.com/v1/payments/confirm", {
      method: "POST",
      headers: { "Authorization": "Basic " + Buffer.from(secret + ":").toString("base64"), "Content-Type": "application/json" },
      body: JSON.stringify({ paymentKey, orderId, amount }),
    });
    const data = await r.json();
    if (!r.ok) return res.status(400).json({ ok: false, error: data.message || "결제 승인 실패" });
    Q.setPlan(req.agent.workspace_id, plan);
    Q.addSubscription(req.agent.workspace_id, { plan, status: "active", amount, payment_key: paymentKey, order_id: orderId });
    Q.addAudit(req.agent.workspace_id, req.agent.email, "plan_change", plan, req.ip);
    res.json({ ok: true, plan });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});

// ---- 이메일/비밀번호 로그인 ----
app.post("/api/auth/login", rateLimit(10, 60000), (req, res) => {
  const { email, password } = req.body || {};
  const ag = Q.agentByEmail(email || "");
  if (!ag || !Q.verifyPassword(ag, password || "")) return res.status(401).json({ error: "이메일 또는 비밀번호가 올바르지 않습니다." });
  Q.addAudit(ag.workspace_id, ag.email, "login", "", req.ip);
  res.json({ token: ag.token, name: ag.name });
});

// ---- 감사 로그 ----
app.get("/api/console/audit", agentAuth, (req, res) => res.json(Q.recentAudit(req.agent.workspace_id)));

// ---- 위젯 설정 (공개) : 임베드 위젯이 외형/인사말을 가져감 ----
app.get("/api/widget-config", (req, res) => {
  const ws = Q.workspaceByKey(req.query.key || "");
  if (!ws) return res.status(404).json({ error: "unknown key" });
  const s = Q.getSettings(ws.id) || {};
  res.json({
    bot_name: s.bot_name || "GOWON Talk",
    accent: s.accent || "#5B53E8",
    welcome: s.welcome || "안녕하세요! 무엇을 도와드릴까요?",
    suggestions: ["배송 문의", "교환·환불", "영업시간", "상담사 연결"],
  });
});

// ---- 대화 상태 변경 (보류 등) ----
app.post("/api/console/conversations/:id/status", agentAuth, (req, res) => {
  const allowed = ["ai_handling", "needs_human", "agent", "hold", "resolved"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "invalid status" });
  Q.setStatus(req.params.id, req.body.status);
  res.json({ ok: true });
});
// ---- 상담사 배분상태 ----
app.get("/api/console/availability", agentAuth, (req, res) => res.json(Q.getAvailability(req.agent.id)));
app.post("/api/console/availability", agentAuth, (req, res) => { Q.setAvailability(req.agent.id, req.body.availability, req.body.max_tickets); Q.addAudit(req.agent.workspace_id, req.agent.email, "availability", req.body.availability, req.ip); res.json({ ok: true }); });

// ---- 전달(transfer) ----
app.post("/api/console/conversations/:id/transfer", agentAuth, (req, res) => {
  Q.transfer(req.params.id, req.body.toAgentId || req.agent.id);
  Q.addMessage(req.params.id, "agent", `[전달] ${req.body.reason || "담당 상담사에게 전달되었습니다."}`);
  Q.addAudit(req.agent.workspace_id, req.agent.email, "transfer", req.params.id, req.ip);
  res.json({ ok: true });
});

// ---- 대화요약 ----
app.post("/api/console/conversations/:id/summary", agentAuth, (req, res) => { Q.saveSummary(req.params.id, req.body.topic || "", req.body.summary || ""); res.json({ ok: true }); });

// ---- 지식 즐겨찾기 ----
app.post("/api/console/kb/:id/favorite", agentAuth, (req, res) => { Q.toggleFav(req.agent.workspace_id, req.params.id); res.json({ ok: true }); });

// ---- 티켓 이력 CSV 내보내기 ----
app.get("/api/console/export", agentAuth, (req, res) => {
  const rows = Q.listConversations(req.agent.workspace_id);
  const head = "id,channel,customer,status,topic,created_at,updated_at\n";
  const body = rows.map((r) => [r.id, r.channel, r.customer_name, r.status, (r.topic || "").replace(/,/g, " "), new Date(r.created_at).toISOString(), new Date(r.updated_at).toISOString()].join(",")).join("\n");
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", "attachment; filename=gowon-tickets.csv");
  res.send("\uFEFF" + head + body);
});

// ---- 비밀번호 변경 ----
app.post("/api/auth/change-password", agentAuth, (req, res) => {
  if (!req.body.password || req.body.password.length < 6) return res.status(400).json({ error: "6자 이상 입력하세요." });
  Q.setPassword(req.agent.id, req.body.password);
  Q.addAudit(req.agent.workspace_id, req.agent.email, "password_change", "", req.ip);
  res.json({ ok: true });
});

app.get("/api/bootstrap", (req, res) => res.json({ publicKey: seed.publicKey, token: seed.token, tossClientKey: process.env.TOSS_CLIENT_KEY || "" }));

app.get("/console", (req, res) => res.sendFile(path.join(__dirname, "public", "console.html")));

// 전역 에러 핸들러
app.use((err, req, res, next) => { console.error("ERROR", req.path, err.message); res.status(500).json({ error: "서버 오류가 발생했습니다." }); });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`GOWON Talk: http://localhost:${PORT}`));
