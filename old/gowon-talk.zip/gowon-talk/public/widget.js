/* GOWON Talk 임베드 위젯 모듈
 * 설치: <script src="https://your-host/widget.js" data-key="pk_..." defer></script>
 * 어떤 웹사이트에도 우측 하단 플로팅 아이콘으로 추가됩니다. (Shadow DOM 격리)
 */
(function () {
  var script = document.currentScript || (function () { var s = document.getElementsByTagName("script"); return s[s.length - 1]; })();
  var KEY = script.getAttribute("data-key") || "";
  var ORIGIN = (function () { try { return new URL(script.src).origin; } catch (e) { return ""; } })();
  var POS = script.getAttribute("data-position") || "right"; // right | left
  var API = function (p, o) { return fetch(ORIGIN + p, o).then(function (r) { return r.json(); }); };

  var host = document.createElement("div");
  host.id = "gowon-talk-widget";
  document.body.appendChild(host);
  var root = host.attachShadow ? host.attachShadow({ mode: "open" }) : host;

  var cfg = { bot_name: "GOWON Talk", accent: "#5B53E8", welcome: "안녕하세요! 무엇을 도와드릴까요?", suggestions: ["배송 문의", "교환·환불", "영업시간", "상담사 연결"] };
  var convId = null, open = false;

  function css() {
    return "" +
      ":host{all:initial}" +
      "*{box-sizing:border-box;font-family:'Pretendard',system-ui,-apple-system,sans-serif}" +
      ".launch{position:fixed;" + (POS === "left" ? "left" : "right") + ":22px;bottom:22px;width:60px;height:60px;border-radius:50%;border:none;cursor:pointer;box-shadow:0 10px 30px rgba(30,30,70,.32);z-index:2147483000;display:flex;align-items:center;justify-content:center;transition:transform .2s}" +
      ".launch:hover{transform:scale(1.06)}" +
      ".launch svg{width:27px;height:27px}" +
      ".badge{position:absolute;top:-3px;right:-3px;background:#EF4444;color:#fff;font-size:11px;font-weight:700;border-radius:20px;min-width:18px;height:18px;display:flex;align-items:center;justify-content:center;padding:0 5px}" +
      ".panel{position:fixed;" + (POS === "left" ? "left" : "right") + ":22px;bottom:94px;width:374px;max-width:calc(100vw - 32px);height:560px;max-height:calc(100vh - 120px);background:#fff;border-radius:18px;overflow:hidden;box-shadow:0 30px 80px -20px rgba(20,20,50,.45);z-index:2147483000;display:none;flex-direction:column;animation:gt-up .3s cubic-bezier(.22,1,.36,1)}" +
      ".panel.on{display:flex}" +
      "@keyframes gt-up{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}" +
      ".hd{padding:16px 18px;color:#fff;display:flex;align-items:center;gap:10px}" +
      ".hd .nm{font-weight:700;font-size:16px}.hd .st{font-size:11.5px;opacity:.9;display:flex;align-items:center;gap:5px}" +
      ".hd .dot{width:7px;height:7px;border-radius:50%;background:#5EEAD4;display:inline-block}" +
      ".x{margin-left:auto;background:none;border:none;color:#fff;font-size:22px;cursor:pointer;opacity:.9;line-height:1}" +
      ".log{flex:1;overflow:auto;padding:16px;background:#F7F6F2;display:flex;flex-direction:column;gap:8px}" +
      ".m{max-width:82%;padding:10px 13px;border-radius:14px;font-size:14px;line-height:1.55}" +
      ".m.them{background:#fff;border:1px solid #E7E3D9;align-self:flex-start;border-bottom-left-radius:5px}" +
      ".m.me{color:#fff;align-self:flex-end;border-bottom-right-radius:5px}" +
      ".m.sys{align-self:center;background:#EEF0F4;color:#555;font-size:12px;border-radius:10px}" +
      ".typing{align-self:flex-start;background:#fff;border:1px solid #E7E3D9;border-radius:14px;padding:11px 14px;display:flex;gap:4px}" +
      ".typing i{width:6px;height:6px;border-radius:50%;background:#bbb;animation:gt-b 1s infinite}" +
      ".typing i:nth-child(2){animation-delay:.15s}.typing i:nth-child(3){animation-delay:.3s}" +
      "@keyframes gt-b{0%,60%,100%{opacity:.3}30%{opacity:1}}" +
      ".sug{display:flex;gap:6px;flex-wrap:wrap;padding:0 14px 8px;background:#F7F6F2}" +
      ".sug button{font-size:12.5px;border:1px solid;border-radius:20px;padding:6px 12px;cursor:pointer;background:#fff}" +
      ".ft{display:flex;gap:8px;padding:12px 14px;border-top:1px solid #EFEDE7;background:#fff}" +
      ".ft input{flex:1;padding:11px 13px;border:1px solid #E7E3D9;border-radius:11px;font-size:14px;outline:none}" +
      ".ft button{border:none;border-radius:11px;width:44px;color:#fff;cursor:pointer;font-size:16px}" +
      ".pw{text-align:center;font-size:10.5px;color:#A8A398;padding:0 0 9px;background:#fff}";
  }

  function el(html) { var d = document.createElement("div"); d.innerHTML = html.trim(); return d.firstChild; }
  var style, launch, panel, logEl, sugEl, inputEl;

  function build() {
    style = document.createElement("style"); style.textContent = css(); root.appendChild(style);
    launch = el('<button class="launch" style="background:' + cfg.accent + '"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></button>');
    launch.onclick = toggle; root.appendChild(launch);
    panel = el('<div class="panel"></div>');
    panel.appendChild(el('<div class="hd" style="background:' + cfg.accent + '"><div><div class="nm">' + esc(cfg.bot_name) + '</div><div class="st"><span class="dot"></span>보통 1분 내 응답</div></div><button class="x">&times;</button></div>'));
    logEl = el('<div class="log"></div>'); panel.appendChild(logEl);
    sugEl = el('<div class="sug"></div>'); panel.appendChild(sugEl);
    var ft = el('<div class="ft"><input placeholder="메시지를 입력하세요"/><button style="background:' + cfg.accent + '">↑</button></div>');
    inputEl = ft.querySelector("input");
    ft.querySelector("button").onclick = function () { send(); };
    inputEl.addEventListener("keydown", function (e) { if (e.key === "Enter") send(); });
    panel.appendChild(ft);
    panel.appendChild(el('<div class="pw">powered by <b>GOWON&nbsp;Talk</b></div>'));
    panel.querySelector(".x").onclick = toggle;
    root.appendChild(panel);
    cfg.suggestions.forEach(function (q) {
      var b = document.createElement("button"); b.textContent = q; b.style.color = cfg.accent; b.style.borderColor = cfg.accent + "55";
      b.onclick = function () { send(q); }; sugEl.appendChild(b);
    });
  }
  function esc(s) { return (s || "").replace(/[&<>]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]; }); }
  function toggle() { open = !open; panel.classList.toggle("on", open); if (open && !logEl.childElementCount) bubble("them", cfg.welcome); if (open) setTimeout(function () { inputEl.focus(); }, 80); }
  function bubble(role, text) {
    var m = document.createElement("div"); m.className = "m " + role; if (role === "me") m.style.background = cfg.accent;
    m.textContent = text; logEl.appendChild(m); logEl.scrollTop = logEl.scrollHeight;
  }
  function typing(on) {
    var t = root.querySelector(".typing");
    if (on && !t) { var d = el('<div class="typing"><i></i><i></i><i></i></div>'); logEl.appendChild(d); logEl.scrollTop = logEl.scrollHeight; }
    else if (!on && t) t.remove();
  }
  function send(val) {
    var v = (val || inputEl.value).trim(); if (!v) return; inputEl.value = "";
    sugEl.style.display = "none"; bubble("me", v); typing(true);
    API("/api/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ publicKey: KEY, channel: "web", conversationId: convId, message: v }) })
      .then(function (r) {
        typing(false);
        if (r.conversationId) convId = r.conversationId;
        bubble("them", r.reply || "잠시만 기다려 주세요.");
        if (r.status === "needs_human") bubble("sys", "전문 상담사에게 연결하고 있습니다…");
        if (r.status === "limit") bubble("sys", "잠시 후 다시 시도해 주세요.");
      })
      .catch(function () { typing(false); bubble("sys", "일시적인 오류가 발생했습니다."); });
  }

  if (KEY && ORIGIN) {
    API("/api/widget-config?key=" + encodeURIComponent(KEY)).then(function (c) { if (c && !c.error) cfg = Object.assign(cfg, c); build(); }).catch(build);
  } else { build(); }
})();
