# GOWON Talk — 구독형 범용 AI 고객상담 플랫폼

GOWON의 멀티 LLM(클로드/GPT/제미나이/자체 LLM) 기반 AI 고객상담 SaaS.
업종 비종속·멀티테넌트. 랜딩 + 운영 콘솔 + 임베드 위젯 + API/DB/결제가 단일 프로젝트로 통합되어 있습니다.

## 실행

    npm install
    cp .env.example .env
    npm start            # http://localhost:3000

- 랜딩: `/`   ·   운영 콘솔: `/console` (기동 시 터미널의 Agent token으로 로그인)
- Node 22+ 필요 (내장 node:sqlite).

## 콘솔 화면 (프리미엄 리디자인)

- 대시보드 — 해결률·인계·CSAT·채널분포 (카운트업 애니메이션)
- 통합 상담 콘솔 — 인계·답변·해결
- 봇 빌더 — 봇 이름·인사말·액센트 색상·채널 토글 + 실시간 미리보기 (노코드)
- 지식베이스 — 고객 질문·답변(FAQ) 등록 → RAG 근거
- 요금제·구독 — 사용량 게이지 + 토스페이먼츠 구독 결제
- 설치 코드 — 위젯 1줄 + 카카오 웹훅 URL

## 요금제·구독 (토스페이먼츠)

`.env`에 `TOSS_CLIENT_KEY`/`TOSS_SECRET_KEY` 설정 시 실결제 작동.
미설정 시 콘솔에서 "데모 구독"으로 요금제 전환을 시연할 수 있습니다.
요금제별 월 상담 한도가 `/api/chat`에서 자동 적용됩니다 (Free 100 · Starter 1,000 · Growth 5,000 · Scale 20,000).

## 배포

- Docker: `docker build -t gowon-talk . && docker run -p 3000:3000 --env-file .env gowon-talk`
- Render: `render.yaml` 포함 (디스크 마운트로 SQLite 영속). 대시보드에서 키 입력.
- Railway: `Procfile` 사용. Variables에 환경변수 등록.
- 운영 시 `DB_PATH`를 영속 볼륨 경로로 지정. 트래픽 증가 시 PostgreSQL 권장.

## 보안

- LLM·토스 키는 서버 환경변수에서만 사용 (클라이언트 노출 0)
- 토스 결제는 서버 `/api/billing/confirm`에서 승인 (위변조 방지)
- 개별·민감 문의는 전문 상담사로 에스컬레이션

## 남은 상용화 작업

1. 카카오 비즈니스 채널 사업자 승인 + 웹훅 서명 검증
2. 인증 강화(OAuth/세션)·권한 분리
3. 개인정보 처리방침·접근 로그·암호화
4. 토스 정기결제(빌링키) 전환, 레이트리밋·모니터링(Sentry)
